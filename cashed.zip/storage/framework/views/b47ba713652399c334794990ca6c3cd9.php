<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Orders <?php $__env->endSlot(); ?>

    <div class="container">
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="d-flex mb-2 justify-content-between">
            <form class="d-flex align-items-center gap-2" method="get">
                <input type="date" class="form-control w-auto" placeholder="Pilih periode awal" name="start_date"
                    value="<?php echo e(request()->start_date ?? date('Y-m-01')); ?>">
                -
                <input type="date" class="form-control w-auto" placeholder="Pilih periode akhir" name="end_date"
                    value="<?php echo e(request()->end_date ?? date('Y-m-d')); ?>">
                <input type="text" class="form-control w-auto" placeholder="Cari order" name="search"
                    value="<?php echo e(request()->search); ?>">
                <button type="submit" class="btn btn-dark">Cari</button>
            </form>

            <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-dark">Buat Order Baru</a>
        </div>

        <div class="card mb-2 overflow-hidden">
            <table class="table m-0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Customer</th>
                        <th>Payment</th>
                        <th>Total</th>
                        <th>User</th>
                        <th>Tanggal</th>
                        <th></th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>Order #<?php echo e($order->id); ?></td>
                            <td><?php echo e($order->customer); ?></td>
                            <td><?php echo e(number_format($order->payment)); ?></td>
                            <td><?php echo e(number_format($order->total)); ?></td>
                            <td><?php echo e($order->user->name); ?></td>
                            <td><?php echo e($order->created_at->format('Y-m-d')); ?><br>
                                <small><?php echo e($order->created_at->format('H:i:s')); ?></small>
                            </td>
                            <td class="text-end">
                                <a href="<?php echo e(route('orders.show', ['order' => $order->id])); ?>"
                                    class="btn btn-sm btn-primary">
                                    Lihat
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">Belum ada order</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php echo e($orders->links()); ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\PIBITI-2024\Pegawai\resources\views/order/index.blade.php ENDPATH**/ ?>